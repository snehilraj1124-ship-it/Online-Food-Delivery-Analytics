-- Online Food Delivery Analytics SQL

SELECT City, COUNT(*) AS total_orders
FROM food_delivery_orders
GROUP BY City ORDER BY total_orders DESC;

SELECT Food_Category, COUNT(*) AS orders,
       ROUND(AVG(Order_Value_INR),2) AS avg_order_value
FROM food_delivery_orders
GROUP BY Food_Category ORDER BY orders DESC;

SELECT Restaurant, COUNT(*) AS orders,
       ROUND(AVG(Order_Value_INR),2) AS avg_order_value,
       ROUND(AVG(Customer_Rating),2) AS avg_rating
FROM food_delivery_orders
GROUP BY Restaurant
ORDER BY orders DESC;

SELECT Payment_Method, COUNT(*) AS usage_count
FROM food_delivery_orders
GROUP BY Payment_Method
ORDER BY usage_count DESC;

SELECT Order_Status, COUNT(*) AS status_count
FROM food_delivery_orders
GROUP BY Order_Status;

SELECT City, ROUND(AVG(Delivery_Time_Min),2) AS avg_delivery_time
FROM food_delivery_orders
WHERE Order_Status='Delivered'
GROUP BY City
ORDER BY avg_delivery_time;

SELECT Customer_Type,
       COUNT(*) AS orders,
       ROUND(AVG(Order_Value_INR),2) AS avg_order_value
FROM food_delivery_orders
GROUP BY Customer_Type;

SELECT Food_Category,
       ROUND(AVG(Customer_Rating),2) AS avg_rating,
       ROUND(AVG(Delivery_Time_Min),2) AS avg_delivery_time
FROM food_delivery_orders
GROUP BY Food_Category;

SELECT Platform, COUNT(*) AS orders,
       ROUND(AVG(Order_Value_INR),2) AS avg_order_value
FROM food_delivery_orders
GROUP BY Platform;
