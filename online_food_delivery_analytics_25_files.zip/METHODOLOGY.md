# Methodology

The project uses synthetic order-level data. Descriptive analytics are performed across geography, restaurants, categories, customers, payments and delivery operations.

The objective is to demonstrate technical analytics skills rather than make claims about a real food-delivery market.
