CREATE TABLE food_delivery_orders (
 Order_ID INT PRIMARY KEY,
 City VARCHAR(50),
 Restaurant VARCHAR(100),
 Food_Category VARCHAR(50),
 Platform VARCHAR(30),
 Payment_Method VARCHAR(40),
 Order_Value_INR DECIMAL(10,2),
 Delivery_Time_Min INT,
 Customer_Rating INT,
 Order_Status VARCHAR(30),
 Discount_Pct DECIMAL(5,2),
 Delivery_Distance_KM DECIMAL(6,2),
 Customer_Type VARCHAR(30)
);
