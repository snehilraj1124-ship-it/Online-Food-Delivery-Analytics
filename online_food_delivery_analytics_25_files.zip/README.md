# 🍔 Online Food Delivery Analytics

## Overview

An end-to-end analytics project using a synthetic dataset of 1,500 food delivery orders. It analyzes order value, restaurant performance, food categories, delivery time, ratings, payment methods, discounts, customer types and platform usage.

## Technology Stack

- Python
- Java
- SQL
- Microsoft Excel
- HTML5
- CSS3
- JavaScript

## Main Analysis

- Order and revenue analysis
- Restaurant performance
- Food category demand
- City performance
- Delivery-time analysis
- Customer ratings
- Payment methods
- Customer segmentation
- Discount analysis
- Platform comparison

## Dataset

The dataset contains 1,500 synthetic orders across 8 cities, 80 restaurants and 7 food categories. No real customer, restaurant or payment information is included.

## Python

```bash
pip install -r requirements.txt
python food_delivery_analysis.py
python restaurant_performance.py
python delivery_analysis.py
python customer_analysis.py
python data_quality_check.py
```

## Java

Compile:
```bash
javac FoodDeliveryAnalytics.java RestaurantAnalytics.java DeliveryMetrics.java Order.java FoodDeliveryApp.java
```

Run:
```bash
java FoodDeliveryAnalytics
java RestaurantAnalytics
```

## SQL

Create the `food_delivery_orders` table using `schema.sql` and execute `food_delivery_analysis.sql`.

## Web Dashboard

Open `dashboard.html` in a modern browser.

## Excel

Use the dataset to create PivotTables and charts for city, restaurant, category, delivery and payment analysis.

## Disclaimer

This is an educational portfolio project using synthetic data. It does not represent real food-delivery business performance.
