# Excel Dashboard Guide

Recommended KPIs:
- Total Orders
- Gross Order Value
- Average Order Value
- Average Delivery Time
- Average Rating
- Cancellation Rate
- Repeat Customer Share

Recommended PivotTables:
1. City vs Orders
2. Restaurant vs Revenue
3. Category vs Orders
4. Payment Method vs Orders
5. Customer Type vs Average Order Value
6. Category vs Rating
7. City vs Delivery Time

Recommended slicers:
City, Food Category, Platform, Payment Method, Customer Type, Order Status.
