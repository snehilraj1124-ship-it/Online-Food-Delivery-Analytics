import pandas as pd

df = pd.read_csv("food_delivery_orders.csv")

print("Total orders:", len(df))
print("Total revenue:", round(df.loc[df.Order_Status=="Delivered","Order_Value_INR"].sum(), 2))
print("Average order value:", round(df.Order_Value_INR.mean(), 2))
print("\nTop categories:")
print(df.Food_Category.value_counts())
print("\nAverage delivery time:")
print(df.groupby("City").Delivery_Time_Min.mean().round(2))
