public class DeliveryMetrics {
    public static double efficiency(double distanceKm, double minutes) {
        return minutes == 0 ? 0 : distanceKm / minutes;
    }
    public static void main(String[] args) {
        System.out.println("Delivery efficiency helper ready.");
    }
}
