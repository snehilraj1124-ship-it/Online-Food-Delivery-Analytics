import pandas as pd

df = pd.read_csv("food_delivery_orders.csv")
summary = df.groupby("Restaurant").agg(
    orders=("Order_ID","count"),
    revenue=("Order_Value_INR","sum"),
    avg_rating=("Customer_Rating","mean"),
    avg_delivery_time=("Delivery_Time_Min","mean")
).round(2).sort_values("revenue", ascending=False)

print(summary.head(15))
summary.to_csv("restaurant_performance_summary.csv")
