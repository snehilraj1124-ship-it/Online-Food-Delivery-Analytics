# Business Insight Framework

Questions supported by the dataset:
- Which cities generate the most orders?
- Which restaurants have high order volume?
- Which categories have high average order value?
- Which payment methods are most used?
- Which cities have longer delivery times?
- How does rating relate to delivery performance?
- Which customer types have higher order value?
- How do platforms compare?
