import pandas as pd

df = pd.read_csv("food_delivery_orders.csv")

summary = df.groupby("Customer_Type").agg(
    orders=("Order_ID","count"),
    avg_order_value=("Order_Value_INR","mean"),
    avg_rating=("Customer_Rating","mean")
).round(2)

print(summary)
