# Java Run Guide

Compile:
`javac FoodDeliveryAnalytics.java RestaurantAnalytics.java DeliveryMetrics.java Order.java FoodDeliveryApp.java`

Run:
`java FoodDeliveryAnalytics`
`java RestaurantAnalytics`

The Java modules demonstrate CSV parsing, aggregation and reusable helper classes.
