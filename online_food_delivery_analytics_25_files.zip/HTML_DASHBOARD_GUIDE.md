# HTML Dashboard Guide

Open `dashboard.html` in a browser. The dashboard provides KPI cards and interactive views for overview, restaurants, delivery and customers.

Files:
- dashboard.html
- dashboard.css
- dashboard.js
