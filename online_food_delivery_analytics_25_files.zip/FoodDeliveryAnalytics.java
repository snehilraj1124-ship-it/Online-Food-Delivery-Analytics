import java.io.*;
public class FoodDeliveryAnalytics {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("food_delivery_orders.csv"));
        br.readLine();
        int orders = 0;
        double revenue = 0;
        String line;
        while ((line = br.readLine()) != null) {
            String[] p = line.split(",", -1);
            orders++;
            revenue += Double.parseDouble(p[6]);
        }
        br.close();
        System.out.println("Orders: " + orders);
        System.out.printf("Gross order value: %.2f%n", revenue);
        System.out.printf("Average order value: %.2f%n", revenue/orders);
    }
}
