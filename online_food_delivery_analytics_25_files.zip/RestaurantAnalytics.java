import java.io.*;
import java.util.*;

public class RestaurantAnalytics {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("food_delivery_orders.csv"));
        String[] h = br.readLine().split(",", -1);
        int restaurant=-1;
        for(int i=0;i<h.length;i++) if(h[i].equals("Restaurant")) restaurant=i;
        Map<String,Integer> counts=new HashMap<>();
        String line;
        while((line=br.readLine())!=null){
            String[] p=line.split(",",-1);
            counts.put(p[restaurant], counts.getOrDefault(p[restaurant],0)+1);
        }
        br.close();
        counts.entrySet().stream()
            .sorted((a,b)->b.getValue()-a.getValue())
            .limit(10)
            .forEach(e->System.out.println(e.getKey()+" -> "+e.getValue()));
    }
}
