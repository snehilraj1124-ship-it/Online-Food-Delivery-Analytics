# SQL Query Reference

The SQL layer covers city performance, restaurant performance, category demand,
payment methods, order status, delivery time, customer type and platform analysis.
