# Project Architecture

CSV Dataset
→ Data Quality Checks
→ Python Analytics / Java Analytics / SQL Queries
→ Excel Reporting
→ HTML/CSS/JavaScript Dashboard

The architecture demonstrates a complete business analytics workflow.
