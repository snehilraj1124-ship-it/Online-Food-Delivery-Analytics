public class FoodDeliveryApp {
    public static void main(String[] args) {
        System.out.println("Online Food Delivery Analytics");
        System.out.println("Use FoodDeliveryAnalytics and RestaurantAnalytics for CSV analysis.");
    }
}
