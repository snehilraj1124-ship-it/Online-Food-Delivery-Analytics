document.addEventListener("DOMContentLoaded",()=>{
 const buttons=document.querySelectorAll("button[data-view"]);
 const view=document.getElementById("view");
 buttons.forEach(btn=>btn.addEventListener("click",()=>{
   buttons.forEach(x=>x.classList.remove("active"));
   btn.classList.add("active");
   view.textContent="Selected view: "+btn.dataset.view;
 }));
});
