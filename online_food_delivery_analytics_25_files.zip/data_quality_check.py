import pandas as pd

df = pd.read_csv("food_delivery_orders.csv")

print("Rows:", len(df))
print("Columns:", len(df.columns))
print("\nMissing values:")
print(df.isna().sum())
print("Duplicate Order IDs:", df["Order_ID"].duplicated().sum())
print("Negative order values:", (df["Order_Value_INR"] < 0).sum())
print("Invalid ratings:", (~df["Customer_Rating"].between(1,5)).sum())
