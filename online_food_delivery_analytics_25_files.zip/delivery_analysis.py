import pandas as pd

df = pd.read_csv("food_delivery_orders.csv")
delivered = df[df["Order_Status"] == "Delivered"]

print("Average delivered-order time:", round(delivered["Delivery_Time_Min"].mean(),2))
print("\nDelivery time by category:")
print(delivered.groupby("Food_Category")["Delivery_Time_Min"].mean().round(2))
print("\nDelivery time by city:")
print(delivered.groupby("City")["Delivery_Time_Min"].mean().round(2))
