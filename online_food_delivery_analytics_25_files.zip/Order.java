public class Order {
    private final int id;
    private final String category;
    private final double value;
    private final int deliveryMinutes;

    public Order(int id, String category, double value, int deliveryMinutes) {
        this.id=id; this.category=category; this.value=value; this.deliveryMinutes=deliveryMinutes;
    }
    public int getId(){return id;}
    public String getCategory(){return category;}
    public double getValue(){return value;}
    public int getDeliveryMinutes(){return deliveryMinutes;}
}
